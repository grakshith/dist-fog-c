from django.apps import AppConfig


class PlantWateringSystemConfig(AppConfig):
    name = 'plant_watering_system'
